def write_df(df,tgt_dir,file_format):

    df.write \
        .format(file_format) \
        .coalesce(10) \
        .partitionBy("year","month","day") \
        .option(saveMode="append") \
        .option("path",tgt_dir) \
        .save()
